# Sign Location Data Collection Metadata

**Dataset Description**: Dataset consists locations of maps around campus and locations of signposts naming buildings
**Data Collection Tool**: *Data was collected using Google Maps on a smart phone
**Latitude/Longitude Format**: ** Latitude and Longitude are in degrees , minutes and seconds
